$(document).ready(function(){
    $("#form_parameter").submit(function(){
        var myhtml = $.ajax({
            type:"POST",  //傳值方式有分 post & get
            url:"PHP/POST_Function/register_finish.php",
            data:{ Out_motor:$('#Out_motor').val(),Out_TDS:$('#Out_TDS').val(),
                   Out_Water:$('#Out_Water').val(),Out_PH:$('#Out_PH').val()},//將表單的值設定好
            async:true,
            success: function(data) {
			alert(data);
            },
            error:function() {
                alert("失敗4");
            }
        }).responseText;
	$("#Out_motor").val("");
	$("#Out_TDS").val("");
	$("#Out_Water").val("");
	$("#Out_PH").val("");
	return false;
    });
});
