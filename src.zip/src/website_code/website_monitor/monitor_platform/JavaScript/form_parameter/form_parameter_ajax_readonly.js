function get_ajax_form() {
    $(document).ready(function () {
        $.ajax({
            url :"PHP/GET_Function/form_parameter_readonly.php",
            method:"GET",
            datatype:"json",
            contentType: "application/json; charset=utf-8",
            async:true,
            success: function(form_parameter) {
                $(document).ready(function() {
                    $("#In_motor").val(form_parameter.motor_parameter);
                    $("#In_TDS").val(form_parameter.TDS);
                    $("#In_Water").val(form_parameter.water);
                    $("#In_PH").val(form_parameter.PH);
                    $("#IOut_motor_now").val(form_parameter.motor_parameter);
                    $("#Out_TDS_now").val(form_parameter.TDS_parameter);
                    $("#Out_Water_now").val(form_parameter.water_parameter);
                    $("#Out_PH_now").val(form_parameter.PH_parameter);
                    });
            },
            error:function() {
                alert("失敗2");
            }
        }).responseText;
    });
}

function get_ajax_form_sensor() {
    $(document).ready(function () {
        $.ajax({
            url :"http://120.113.74.177/jsontest/empdata.json",
            method:"GET",
            datatype:"json",
            async:true,
            success: function(form_parameter) {
		    alert(form_parameter);
                $(document).ready(function() {

                    });
            },
            error:function() {
                alert("sensor失敗");
            }
        }).responseText;
    });
}
