function get_ajax() {
    $(document).ready(function () {
        $.ajax({
	    url :"PHP/GET_Function/io_status_connect.php",
            method:"GET",
            datatype:"json",
	    contentType: "application/json; charset=utf-8",
	    async:true,	
            success: function(test_rowio) {        
                    	$(document).ready(function() {
            			setTimeout("changeImage(" + test_rowio.one + "),changeImage1(" + test_rowio.two + "),changeImage2(" + test_rowio.three + "),changeImage3(" + test_rowio.four + "),changeImage4(" + test_rowio.five + "),changeImage5(" + test_rowio.six + "),changeImage6(" + test_rowio.seven + "),changeImage7(" + test_rowio.eight + "),changeImage8(" + test_rowio.nine + "),changeImage9(" + test_rowio.ten + "),changeImage10("+test_rowio.eleven + "),changeImage11(" + test_rowio.twelve + "),changeImage12(" + test_rowio.thirteen + ")" ,100);	
	 		});
            },
            error:function(xhr, ajaxOptions, thrownError) {
		console.log(xhr.responseText);
                alert("失敗3");
            }
        }).responseText;
	


    });
}
