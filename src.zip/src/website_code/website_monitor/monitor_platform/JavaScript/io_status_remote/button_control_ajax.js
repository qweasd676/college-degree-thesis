function button_control_ajax(button_val,button_val1) {
    var button_val;
    var button_val1;	
    $(document).ready(function () {
     	$.ajax({
            url :"PHP/POST_Function/button_control.php",
            method:"POST",
            async:true,
            data:{button_val:(button_val),button_val1:(button_val1)},
            success:function(html_data) {

                    },
            error:function() {
                alert("失敗7");
            }
        }).responseText;
    });
}
function button_control_initial() {
    var button_val =4;
    var button_val1 = 0;	
    $(document).ready(function () {
     	$.ajax({
            url :"PHP/POST_Function/button_control.php",
            method:"POST",
            async:true,
            data:{button_val:(button_val),button_val1:(button_val1)},
            success:function(html_data) {

                    },
            error:function() {
                alert("失敗5");
            }
        }).responseText;
    });
}
function button_control_close() {
    var button_val =4;
    var button_val1 = 0;
    $(document).ready(function () {
     	$.ajax({
            url :"PHP/POST_Function/button_control.php",
            method:"POST",
            async:true,
            data:{button_val:(button_val),button_val1:(button_val1)},
            success:function(html_data) {

                    },
            error:function() {
                alert("失敗6");
            }
        }).responseText;
    });
}

