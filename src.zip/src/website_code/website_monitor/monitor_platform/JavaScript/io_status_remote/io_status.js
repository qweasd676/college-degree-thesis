
function changeImage(xx) {
    var image = document.getElementById('myImage');
    var xx;
    if (xx == 0 ) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage1(xx1) {
    var image = document.getElementById('myImage1');
    var xx1;
    if (xx1 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage2(xx2) {
    var image = document.getElementById('myImage2');
    var xx2;
    if (xx2 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage3(xx3) {
    var image = document.getElementById('myImage3');
    var xx3;
    if (xx3 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage4(xx4) {
    var image = document.getElementById('myImage4');
    var xx4;
    if (xx4 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage5(xx5) {
    var image = document.getElementById('myImage5');
    var xx5;
    if (xx5 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage6(xx6) {
    var image = document.getElementById('myImage6');
    var xx6;
    if (xx6 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage7(xx7) {
    var image = document.getElementById('myImage7');
    var xx7;
    if (xx7 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage8(xx8) {
    var image = document.getElementById('myImage8');
    var xx8;
    if (xx8 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage9(xx9) {
    var image = document.getElementById('myImage9');
    var xx9;
    if (xx9 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage10(xx10) {
    var image = document.getElementById('myImage10');
    var xx10;
    if (xx10 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage11(xx11) {
    var image = document.getElementById('myImage11');
    var xx11;
    if (xx11 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";
    }
}
function changeImage12(xx12) {
    var image = document.getElementById('myImage12');
    var xx12;
    if (xx12 == 0) {
        image.src = "image/gray_io_status.png";
    } else {
        image.src = "image/green_io_status.png";

    }
}


function changeImage20() {
    var image = document.getElementById('myImage20');
    var xx20 = 1;
    var xx20_1;
    if (image.src.match("image/button_remoteON")) {
        image.src = "image/button_remoteOFF.png";
	xx20_1 = 0;
         $(document).ready(function () {
            setTimeout("button_control_ajax("+ xx20 +","+ xx20_1 +")", 100);
         });
    } else {
        image.src = "image/button_remoteON.png";
	 xx20_1 = 1;
         $(document).ready(function () {
            setTimeout("button_control_ajax("+ xx20 +","+ xx20_1 +")", 100);
         });
    }
}

function changeImage21() {
    var image = document.getElementById('myImage21');
    var xx21 = 2;
    var xx21_1;
    if (image.src.match("image/button_endON")) {
        image.src = "image/button_endOFF.png";
	xx21_1 = 0;
         $(document).ready(function () {
            setTimeout("button_control_ajax("+ xx21 +","+ xx21_1 +")", 100);
         });
    } else {
        image.src = "image/button_endON.png";
	 xx21_1 = 1;
         $(document).ready(function () {
            setTimeout("button_control_ajax("+ xx21 +","+ xx21_1 +")", 100);
         });
    }
}

function changeImage22() {
    var image = document.getElementById('myImage22');
    var xx22 = 3;
    var xx22_1;
    if (image.src.match("image/button_releaseON")) {
        image.src = "image/button_releaseOFF.png";
	xx22_1 = 0;
         $(document).ready(function () {
            setTimeout("button_control_ajax("+ xx22 +","+ xx22_1 +")", 100);
         });
    } else {
        image.src = "image/button_releaseON.png";
	 xx22_1 = 1;
         $(document).ready(function () {
            setTimeout("button_control_ajax("+ xx22 +","+ xx22_1 +")", 100);
         });
    }
}




