var gaugeOptions = {

    chart: {
        type: 'solidgauge'
    },

    title: null,

    pane: {
        center: ['50%', '85%'],
        size: '140%',
        startAngle: -90,
        endAngle: 90,
        background: {
            backgroundColor:
                Highcharts.defaultOptions.legend.backgroundColor || '#EEE',
            innerRadius: '60%',
            outerRadius: '100%',
            shape: 'arc'
        }
    },

    tooltip: {
        enabled: false
    },

    // the value axis
    yAxis: {
        stops: [
            [0.1, '#55BF3B'], // green
            [0.5, '#DDDF0D'], // yellow
            [0.9, '#DF5353'] // red
        ],
        lineWidth: 0,
        minorTickInterval: null,
        tickAmount: 2,
        title: {
            y: -70
        },
        labels: {
            y: 16
        }
    },

    plotOptions: {
        solidgauge: {
            dataLabels: {
                y: 5,
                borderWidth: 0,
                useHTML: true
            }
        }
    }
};


/*var chartSpeed = Highcharts.chart('container-motor_speed', Highcharts.merge(gaugeOptions, {
    yAxis: {
        min: 0,
        max: 200,
        title: {
            text: 'motor-Speed'
        }
    },

    credits: {
        enabled: false
    },

    series: [{
        name: 'motor-Speed',
        data: [80],
        dataLabels: {
            format:
                '<div style="text-align:center">' +
                '<span style="font-size:10px">{y}</span><br/>' +
                '<span style="font-size:6px;opacity:0.4">km/h</span>' +
                '</div>'
        },
        tooltip: {
            valueSuffix: 'km/h'
        }
    }]
})); */
var charttemperature = Highcharts.chart('container-temperature', Highcharts.merge(gaugeOptions, {
    yAxis: {
        min: 0,
        max: 200,
        title: {
            text: 'temperature'
        }
    },

    credits: {
        enabled: false
    },

    series: [{
        name: 'temperature',
        data: [80],
        dataLabels: {
            format:
                '<div style="text-align:center">' +
                '<span style="font-size:10px">{y}</span><br/>' +
                '<span style="font-size:6px;opacity:0.4">km/h</span>' +
                '</div>'
        },
        tooltip: {
            valueSuffix: 'km/h'
        }
    }]
}));
var chartTDS = Highcharts.chart('container-TDS', Highcharts.merge(gaugeOptions, {
    yAxis: {
        min: 0,
        max: 200,
        title: {
            text: 'TDS'
        }
    },
    credits: {
        enabled: false
    },

    series: [{
        name: 'TDS',
        data: [1],
        dataLabels: {
            format:
                '<div style="text-align:center">' +
                '<span style="font-size:10px">{y}</span><br/>' +
                '<span style="font-size:6px;opacity:0.4">km/h</span>' +
                '</div>'
        },
        tooltip: {
            valueSuffix: ''
        }
    }]

}));
var chartWater = Highcharts.chart('container-water', Highcharts.merge(gaugeOptions, {
    yAxis: {
        min: 0,
        max: 200,
        title: {
            text: 'water'
        }
    },
    credits: {
        enabled: false
    },

    series: [{
        name: 'water',
        data: [1],
        dataLabels: {
            format:
                '<div style="text-align:center">' +
                '<span style="font-size:10px">{y}</span><br/>' +
                '<span style="font-size:6px;opacity:0.4">km/h</span>' +
                '</div>'
        },
        tooltip: {
            valueSuffix: ''
        }
    }]

}));
var chartPH = Highcharts.chart('container-PH', Highcharts.merge(gaugeOptions, {
    yAxis: {
        min: 0,
        max: 15,
        title: {
            text: 'PH'
        }
    },
    credits: {
        enabled: false
    },

    series: [{
        name: 'PH',
        data: [1],
        dataLabels: {
            format:
                '<div style="text-align:center">' +
                '<span style="font-size:10px">{y}</span><br/>' +
                '<span style="font-size:6px;opacity:0.4">km/h</span>' +
                '</div>'
        },
        tooltip: {
            valueSuffix: ''
        }
    }]

}));

// Bring life to the dials
setInterval(function () {
    // Speed
    var point_temperature = charttemperature.series[0].points[0],
	point_TDS = chartTDS.series[0].points[0],
	point_water = chartWater.series[0].points[0],
	point_PH = chartPH.series[0].points[0];
	$.ajax({
 		url :"PHP/GET_Function/form_parameter_readonly.php",
		method:"GET",
		datatype:"json",
		contentType: "application/json; charset=utf-8",
		async:true,
		success: function(form_parameter) {
			point_temperature.update(parseInt(form_parameter.temperature));
			point_TDS.update(parseInt(form_parameter.TDS));
			point_water.update(parseInt(form_parameter.water));
			point_PH.update(parseInt(form_parameter.PH));
		},
		error:function() {
    		alert("失敗1");
	 	}
	}).responseText;
}, 1000);
