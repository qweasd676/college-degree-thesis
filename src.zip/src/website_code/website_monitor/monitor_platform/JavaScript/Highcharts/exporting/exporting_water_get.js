$.getJSON('PHP/GET_Sensor_Data/water_Sensor.php', function (data) {
    // Create the chart
    Highcharts.stockChart('container_water', {


        rangeSelector: {
            selected: 1
        },

        title: {
            text: 'water sensor'
        },

        series: [{
            name: 'water',
            data: data,
            tooltip: {
                valueDecimals: 2
            }
        }]
    });
});

