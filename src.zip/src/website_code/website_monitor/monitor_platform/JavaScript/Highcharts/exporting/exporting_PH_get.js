$.getJSON('PHP/GET_Sensor_Data/ph_Sensor.php', function (data) {

    // Create the chart PHP/GET_Sensor_Data/ph_data.json
    Highcharts.stockChart('container_PH', {


        rangeSelector: {
            selected: 1
        },

        title: {
            text: 'PH sensor'
        },
     /*   navigator: {
            enabled: false
        },*/

        series: [{
            name: 'PH',
            data: data,
            tooltip: {
                valueDecimals: 2
            }
        }]
    });
});

