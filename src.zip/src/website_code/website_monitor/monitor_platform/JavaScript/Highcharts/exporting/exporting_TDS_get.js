$.getJSON('PHP/GET_Sensor_Data/TDS_Sensor.php', function (data) {
    // Create the chart
    Highcharts.stockChart('container_TDS', {


        rangeSelector: {
            selected: 1
        },

        title: {
            text: 'TDS sensor'
        },

        series: [{
            name: 'TDS',
            data: data,
            tooltip: {
                valueDecimals: 2
            }
        }]
    });
});

