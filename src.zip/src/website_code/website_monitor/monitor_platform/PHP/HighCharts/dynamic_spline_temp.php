<?php
    header('Content-Type: application/json; charset=utf-8');
?>
<?php
    include("mysql_connect.inc.php");
    //連線第一個數據庫
    $sql_query = "SELECT * FROM `temp_table` order by time desc limit 1";
    $result_sensor_temp = mysqli_query($conn,$sql_query);
    $row_sensor_temp = mysqli_fetch_array($result_sensor_temp);

    $form_parameter = [
        "temperature" => $row_sensor_temp[1]
   
    ];
    echo json_encode($form_parameter);
?>
