<?php
    header('Content-Type: application/json; charset=utf-8');
?>
<?php
    include("mysql_connect.inc.php");
    //連線第一個數據庫
    $sql_query = "SELECT * FROM `hardness_table` order by time desc limit 1";
    $result_sensor_TDS = mysqli_query($conn,$sql_query);
    $row_sensor_TDS = mysqli_fetch_array($result_sensor_TDS);

    $form_parameter = [
        "TDS"   => $row_sensor_TDS[1]
    ];
    echo json_encode($form_parameter);
?>
