<?php
    header('Content-Type: application/json; charset=utf-8');
?>
<?php
    include("mysql_connect.inc.php");
    //連線第一個數據庫
    $sql_query = "SELECT * FROM `pH_table` order by time desc limit 1";
    $result_sensor_PH = mysqli_query($conn,$sql_query);
    $row_sensor_PH = mysqli_fetch_array($result_sensor_PH);


    $form_parameter = [
        "pH"    => $row_sensor_PH[1]
    ];
    echo json_encode($form_parameter);
?>
