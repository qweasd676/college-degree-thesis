<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--先呼叫mysql_connect.inc.php與mysql連線,然後再從database取值傳給,此值為$row,再丟到其他地方做使用。-->
<?php
    include("mysql_connect.inc.php");
    $sql_query = "SELECT * FROM test";
    $result = mysqli_query($conn,$sql_query);
    $row = mysqli_fetch_array($result);
?>
