<?php session_start(); ?>
<!--上方語法為啟用session，此語法要放在網頁最前方-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
//連接資料庫
//只要此頁面上有用到連接MySQL就要include它
//搜尋PLC參數 並傳至前台
include("mysql_connect.inc.php");
$username = $_POST['username'];
$password = $_POST['password'];

//搜尋資料庫資料

	$sql_query_login="SELECT * FROM member_table where username='$username' AND password='$password'";
	$result1=mysqli_query($conn,$sql_query_login) or die("查詢失敗");
	if(mysqli_num_rows($result1)){
	$_SESSION['username'] = $username;
        echo '登入成功!';
        echo '<meta http-equiv=REFRESH CONTENT=1;url=member.php>';
	}

/*
$sql = "SELECT username FROM member_table ";
$result = mysql_query($sql);
$row = @mysql_fetch_row($result);
*/
//判斷帳號與密碼是否為空白
//以及MySQL資料庫裡是否有這個會員
/*if($username != null && $password != null && $row[1] == $username && $row[2] == $password)
{
        //將帳號寫入session，方便驗證使用者身份
        $_SESSION['username'] = $username;
        echo '登入成功!';
        echo '<meta http-equiv=REFRESH CONTENT=1;url=member.php>';
}*/
else
{
        echo '登入失敗!';
        echo '<meta http-equiv=REFRESH CONTENT=1;url=index.php>';
}

?>
