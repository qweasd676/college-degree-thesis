<?php
    header('Content-Type: application/json; charset=utf-8');
?>
<?php
    include("mysql_connect.inc.php");
    //連線第一個數據庫
    $sql_query = "SELECT * FROM `temp_table` order by time desc limit 1";
    $result_sensor_temp = mysqli_query($conn,$sql_query);
    $row_sensor_temp = mysqli_fetch_array($result_sensor_temp);
    //連線第二個數據庫
    $sql_query = "SELECT * FROM `hardness_table` order by time desc limit 1";
    $result_sensor_TDS = mysqli_query($conn,$sql_query);
    $row_sensor_TDS = mysqli_fetch_array($result_sensor_TDS);
    //連線第三個數據庫
    $sql_query = "SELECT * FROM `flow_rate_table` order by time desc limit 1";
    $result_sensor_water = mysqli_query($conn,$sql_query);
    $row_sensor_water = mysqli_fetch_array($result_sensor_water);
    //連線第四個數據庫
    $sql_query = "SELECT * FROM `pH_table` order by time desc limit 1";
    $result_sensor_PH = mysqli_query($conn,$sql_query);
    $row_sensor_PH = mysqli_fetch_array($result_sensor_PH);
    //連線第五個數據庫
    $sql_query = "SELECT * FROM `alarm_parameter_table` order by time desc limit 1";
    $result_parameter = mysqli_query($conn,$sql_query);
    $row_parameter = mysqli_fetch_array($result_parameter); 

    $form_parameter = [
        "temperature" => $row_sensor_temp[1],
        "TDS"   => $row_sensor_TDS[1],
        "water" => $row_sensor_water[1],
        "PH"    => $row_sensor_PH[1],
        "TDS_parameter"   => $row_parameter[2],
        "water_parameter" => $row_parameter[1],
        "PH_parameter"    => $row_parameter[3]
    ];
    echo json_encode($form_parameter);
?>

