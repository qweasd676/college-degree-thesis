<?php
    header('Content-Type: application/json; charset=utf-8');
?>
<?php
    include("mysql_connect.inc.php");
    $sql_query = "SELECT * FROM IO_Status";
    $result_io = mysqli_query($conn,$sql_query);
    $row_io = mysqli_fetch_array($result_io);

    $test_rowio = [
	"one"      => "$row_io[0]",
	"two"      => "$row_io[1]",
	"three"    => "$row_io[2]",
	"four"     => "$row_io[3]",
	"five"     => "$row_io[4]",
	"six"      => "$row_io[5]",
	"seven"    => "$row_io[6]",
	"eight"    => "$row_io[7]",
	"nine"     => "$row_io[8]",
	"ten"      => "$row_io[9]",
	"eleven"   => "$row_io[10]",
	"twelve"   => "$row_io[11]",
	"thirteen" => "$row_io[12]"

    ];	
    
    echo json_encode($test_rowio);
?>
