<?php 
    /*json格式*/
    header('Content-Type: application/json; charset=utf-8');
?>
<?php
    $conn=new mysqli('localhost','chen','n0u9dceo','project');
    //$conn = new PDO('mysql:host=localhost;dbname=project', 'chen', 'n0u9dceo');
?>  
