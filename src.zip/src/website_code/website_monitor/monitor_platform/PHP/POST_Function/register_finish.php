<?php
session_start();
include("mysql_connect.php");
//做修改參數設定
//$Out_motor = $_POST['Out_motor'];
$Out_TDS = $_POST['Out_TDS'];
$Out_Water = $_POST['Out_Water'];
$Out_PH = $_POST['Out_PH'];

//判斷帳號密碼是否為空值
//確認密碼輸入的正確性
if($Out_TDS != null && $Out_Water != null && $Out_PH != null & $_SESSION['viewer_qualification'] == 1)
	{
		//新增資料進資料庫語法
		$sql = "insert into alarm_parameter_table (flow_rate,hardness,pH_value) values ('".$Out_Water."', '".$Out_TDS."','".$Out_PH."')";
		if($conn->query($sql) === TRUE)
		{
		        echo '新增成功!';
		       // echo '<meta http-equiv=REFRESH CONTENT=2;url=http://120.113.74.177/test/test_platform/monit_platform.php>';
		}
		else
		{
		        echo '新增失敗!';
		       // echo '<meta http-equiv=REFRESH CONTENT=2;url=http://120.113.74.177/test/test_platform/monit_platform.php>';
		}
	}
else
{
        echo '無權修改或是參數未填寫完!';
        //echo '<meta http-equiv=REFRESH CONTENT=2;url=http://120.113.74.177/test/test_platform/monit_platform.php>';
}
?>
