<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
    include("mysql_connect.php");
    //做修改參數設定
    $button_parameter =$_POST['button_val'];
    $button_status =$_POST['button_val1'] ;
    if($button_parameter ==1 ){
        $sql ="UPDATE `Button_Parameter` SET `button_controll` = '".$button_status."'";
        if($conn->query($sql) === TRUE)
        {    
	    echo '新增成功!';
        }
        else
        {
            echo '新增失敗!';
        }
    }
    elseif($button_parameter ==2){
        $sql = "UPDATE `Button_Parameter` SET `button_end` = '".$button_status."'";
        if($conn->query($sql) === TRUE)
        {
            echo '新增成功!';
        }
        else
        {
            echo '新增失敗!';
        }
    }
    elseif($button_parameter ==3){
        $sql = "UPDATE `Button_Parameter` SET `button_release` = '".$button_status."'";
        if($conn->query($sql) === TRUE)
        {
            echo '新增成功!';
        }
        else
        {
            echo '新增失敗!';
        }
    }
    elseif($button_parameter ==4){
        $sql = "UPDATE `Button_Parameter` SET `button_controll` = '".$button_status."',`button_end` = '".$button_status."',`button_release` = '".$button_status."'";
        if($conn->query($sql) === TRUE)
        {
            echo '新增成功!';
        }
        else
        {
            echo '新增失敗!';
        }
    }
    else{
        echo "傳送失敗";
    }
?>

