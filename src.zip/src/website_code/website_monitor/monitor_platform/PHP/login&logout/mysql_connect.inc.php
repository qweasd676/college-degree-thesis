<?php
$conn=new mysqli('120.113.74.177','project','ps45gt8n','project');	//固定ip,帳號,密碼,資料庫名稱
?>  
