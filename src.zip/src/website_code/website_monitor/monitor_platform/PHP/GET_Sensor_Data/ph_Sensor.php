<?php
    header('Content-Type: application/json');
?>
<?php
    include("mysql_connect.inc.php");
    $sql_query = "SELECT * FROM `pH_table` order by time desc limit 1000";
    $result_sensor_temp = mysqli_query($conn,$sql_query);
    $row_sensor_temp = mysqli_fetch_all($result_sensor_temp); 
    for($i=0 ; $i<1000; $i++){
        $data[$i] = [
	      strtotime($row_sensor_temp[999-$i][2])*1000,floatval($row_sensor_temp[999-$i][1])
        ];
        if($data[$i] == [0,0]){
           unset($data[$i]);
	       break;
	}
    }

    $json_string = json_encode($data,JSON_PRETTY_PRINT ^ JSON_UNESCAPED_UNICODE);
    file_put_contents('ph_data.json', $json_string);    
    echo json_encode($data);
?>

