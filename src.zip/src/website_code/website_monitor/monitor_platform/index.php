<?php session_start(); ?>
<?php 
include("http://120.113.74.177/home_page/php/mysql_connect.inc.php");

if($_SESSION['username'] == null){
	$login_check = 0;
}else{
	$login_check = 1;
}
?>
<!DOCTYPE html>
<html lang="zh-Hant-TW">
    <head>
        <meta charset="UTF-8">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script type="text/javascript" src="https://code.jquery.com/jquery-latest.min.js"></script>
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	
	<!--highcharts 導入函式--->
	<script src="https://code.highcharts.com/stock/highstock.js"></script>
	<script src="https://code.highcharts.com/highcharts-more.js"></script>
	<script src="https://code.highcharts.com/modules/solid-gauge.js"></script>
        <script src="https://code.highcharts.com/modules/exporting.js"></script>
        <script src="https://code.highcharts.com/modules/export-data.js"></script>
	<script src="https://code.highcharts.com/stock/modules/exporting.js"></script>
   	<script src="https://code.highcharts.com/stock/modules/export-data.js"></script>

 	<!--呼叫--->
        <script type="text/javascript" src="JavaScript/HTML_label_tag/Page_tag.js"></script>
        <script type="text/javascript" src="JavaScript/form_parameter/form_parameter_ajax.js"></script>
	<script type="text/javascript" src="JavaScript/form_parameter/form_parameter_ajax_readonly.js"></script>
        <script type="text/javascript" src="JavaScript/io_status_remote/get_ajax.js"></script>
        <script type="text/javascript" src="JavaScript/io_status_remote/io_status.js"></script>
        <script type="text/javascript" src="JavaScript/io_status_remote/button_control_ajax.js"></script>
        <link rel = "stylesheet" type = "text/css" href = "CSS/Basic_setting_mobile.css" media="only screen and (min-width: 0px) and (max-width: 1022px)">
	<link rel = "stylesheet" type = "text/css" href = "CSS/Basic_setting.css" media="only screen and (min-width: 1023px)">

	<!--ajax & bootstrap 導入函式--->
	<link rel="stylesheet" href="http://120.113.74.177/home_page/css/bootstrap.min.css">
	<script src="http://120.113.74.177/home_page/scripts/jquery-3.2.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

        <title>測試平台</title>
    </head>
    <body >
	<script type="text/javascript" language="javascript">
	/*window.onbeforeunload= function(e){  
　　		var e = window.event||e; 
　　		e.returnValue=("當按鈕沒解除完,強行離開會發生問題");
	} */
        $(document).ready(function () {
	    setTimeout("button_control_initial()", 100);
            setInterval("get_ajax(),get_ajax_form()", 1010);
        });
    	</script>

	<!--選單列--->
<nav class="navbar bg-dark navbar-dark navbar-expand-sm justify-content-between fixed-top">
	<!--navbar logo-->
	<a class="navbar-brand" href="#"><img src="http://120.113.74.177/home_page/images/water5.png" alt="logo" style= "height:55px;"></a>
	<!--下拉選單-->
	<button id="collapse_btn" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="collapsibleNavbar">
		<ul id="nav" class="navbar-nav">
			<li class="nav-item"><a class="nav-link" href="http://120.113.74.177/index.php">首頁</a></li>
			<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">工作人員專區</a>
				<div class="dropdown-menu">
					<div id="login_but"></div>
					<div id="login_inf">		
						<a class="dropdown-item" id="" href="#" ><?php echo "user:".$_SESSION['username']?></a>
						<a class="dropdown-item" id="" href="http://120.113.74.177/home_page/php/logout.php">使用者登出</a>
					</div>
				</div>
			</li>
		</ul>
	</div>
</nav>

        <div id="sitebody">    
            <div id="content">
                <div id = "abgne_tab">
                    <ul class = "tabs">
                        <li><a href = "#tab1">數據即時監測</a></li>
			<li><a href = "#tab2">數據歷史紀錄</a></li>
                        <li><a href = "#tab3">修改數據</a></li>
                        <li><a href = "#tab4">機台控制</a></li>
                    </ul>
                    <div class="tab_container">
                        <div id="tab1" class="tab_content">
				<!-- 即時動態曲線圖 -->
				<div id="container_temp" style="height: 400px; min-width: 310px"></div>
				<script type="text/javascript" src="JavaScript/Highcharts/dynamic_spline_temp.js"></script>
				<div id="container_hardness" style="height: 400px; min-width: 310px"></div>
				<script type="text/javascript" src="JavaScript/Highcharts/dynamic_spline_hardness.js"></script>
				<div id="container_flow_rate" style="height: 400px; min-width: 310px"></div>
				<script type="text/javascript" src="JavaScript/Highcharts/dynamic_spline_flow_rate.js"></script>
				<div id="container_pH" style="height: 400px; min-width: 310px"></div>
				<script type="text/javascript" src="JavaScript/Highcharts/dynamic_spline_pH.js"></script> 

                        </div>
			<div id="tab2" class="tab_content">
				<!-- 大數據曲線圖 -->
				<div id="container_TDS" style="height: 400px; min-width: 310px"></div>
				<script type="text/javascript" src="JavaScript/Highcharts/exporting/exporting_TDS_get.js"></script>
				<div id="container_water" style="height: 400px; min-width: 310px"></div>
				<script type="text/javascript" src="JavaScript/Highcharts/exporting/exporting_water_get.js"></script>
				<div id="container_PH" style="height: 400px; min-width: 310px"></div>
				<script type="text/javascript" src="JavaScript/Highcharts/exporting/exporting_PH_get.js"></script>
                        </div>

                        <div id="tab3" class="tab_content">
                            <form id = "form_parameter" name = "form_parameter" method="POST">
                           <table>
                               <tr>
				   <td class="tab3_left"><p>即時數據</p></td>
				   <td class="tab3_right"> </td>
				   <td class="tab3_submit"> </td>
                               </tr>
                               <tr>
                                   <td class="tab3_left">硬水檢測：</td>
                                   <td class="tab3_right"><input type="text" name="In_TDS" id="In_TDS" readonly></td>
				   <td class="tab3_submit"> </td>
			      </tr>
                               <tr>
                                   <td class="tab3_left">水流計：</td>
                                   <td class="tab3_right"><input type="text" name="In_Water" id="In_Water" readonly></td>
				   <td class="tab3_submit"> </td>
				</tr>
                               <tr>
                                   <td class="tab3_left">PH檢測：</td>
                                   <td class="tab3_right"><input type="text" name="In_PH" id="In_PH" readonly></td>
				   <td class="tab3_submit"> </td>
				</tr>
                               <tr>
                                   <td class="tab3_left"><p>當前設定值</p></td>
				   <td class="tab3_right"> </td>
				   <td class="tab3_submit"> </td>
                               </tr>
				<tr>
				   <td class="tab3_left">目前硬水檢測額定值：</td>
                                   <td class="tab3_right"><input type="text" name="Out_TDS_now" id="Out_TDS_now" readonly></td>
				   <td class="tab3_submit"> </td>
				</tr>
				<tr>
                                   <td class="tab3_left">目前水流計額定值：</td>
                                   <td class="tab3_right"><input type="text" name="Out_Water_now" id="Out_Water_now" readonly></td>
				   <td class="tab3_submit"> </td>
				</tr>
				<tr>
                                   <td class="tab3_left">目前PH檢測額定值：</td>
                                   <td class="tab3_right"><input type="text" name="Out_PH_now" id="Out_PH_now" readonly></td>
				   <td class="tab3_submit"> </td>
				</tr>
                               <tr>
                                   <td class="tab3_left"><p>設定值</p></td>
				   <td class="tab3_right"> </td>
				   <td class="tab3_submit"> </td>
                               </tr>

				<tr>
				   <td class="tab3_left">硬水檢測額定值：</td>
                                   <td class="tab3_right"><input type="text" name="Out_TDS" id="Out_TDS"  autocomplete="off"></td>
				   <td class="tab3_submit"> </td>
                               </tr>
				<tr>
                                   <td class="tab3_left">水流計額定值：</td>
                                   <td class="tab3_right"><input type="text" name="Out_Water" id="Out_Water"  autocomplete="off"></td>
				   <td class="tab3_submit"> </td>
                               </tr>
				<tr>
                                   <td class="tab3_left">PH檢測額定值：</td>
                                   <td class="tab3_right"><input type="text" name="Out_PH" id="Out_PH"  autocomplete="off"></td>
				   <td class="tab3_right"> </td>
                                   <td class="tab3_submit"><input type = "submit" value="修改參數"></td>
                               </tr>
                           </table>
                           </form>

                        </div>
                        <div id="tab4" class="tab_content">
                            <!--<form name="form" method="post" action="test.php">-->
			    <table width="100%">
				<tr>
				    <th><div class="outer" >
				          <div id="container-temperature" class="chart-container"></div>
				          <script type="text/javascript" src="JavaScript/Highcharts/Solid_gauge.js"></script>
				        </div>temperature
				    </th>
				    <th><div class="outer" >
				          <div id="container-TDS" class="chart-container"></div>
				          <script type="text/javascript" src="JavaScript/Highcharts/Solid_gauge.js"></script>
				        </div>TDS
				    </th>
				    <th><div class="outer" >
				          <div id="container-water" class="chart-container"></div>
				          <script type="text/javascript" src="JavaScript/Highcharts/Solid_gauge.js"></script>
				        </div>water-speed
				    </th>
				    <th><div class="outer" >
				          <div id="container-PH" class="chart-container"></div>
				          <script type="text/javascript" src="JavaScript/Highcharts/Solid_gauge.js"></script>
				        </div>PH
				    </th>
				</tr>
			    </table>
			    <br><br>
                            <table>
                                <tr>
                                    <th><img id="myImage"   src="image/gray_io_status.png" ></th>
                                    <th><img id="myImage1"  src="image/gray_io_status.png"></th>
                                    <th><img id="myImage2"  src="image/gray_io_status.png"></th>
                                    <th><img id="myImage3"  src="image/gray_io_status.png"></th>
                                    <th><img id="myImage4"  src="image/gray_io_status.png"></th>
                                    <th><img id="myImage5"  src="image/gray_io_status.png"></th>
                                    <th><img id="myImage6"  src="image/gray_io_status.png"></th>
                                </tr>
                                <tr class="text">
                                    <th>目前狀態為手動程序</th>
                                    <th>目前狀態為自動程序</th>
                                    <th>目前狀態為異常程序</th>
                                    <th>COS_A_手動</th>
                                    <th>COS_B_自動</th>
                                    <th>E.M.S_A</th>
                                    <th>PB1_啟動按鈕</th>
                                </tr>
                                <tr>
                                    <th><img id="myImage7"   src="image/gray_io_status.png"></th>
                                    <th><img id="myImage8"   src="image/gray_io_status.png"></th>
                                    <th><img id="myImage9"   src="image/gray_io_status.png"></th>
                                    <th><img id="myImage10"  src="image/gray_io_status.png"></th>
                                    <th><img id="myImage11"  src="image/gray_io_status.png"></th>
                                    <th><img id="myImage12"  src="image/gray_io_status.png"></th>
                                </tr>
                                <tr class="text">
                                    <th>PB2_結束按鈕</th>
                                    <th>PB3_解除按鈕</th>
                                    <th>抽水馬達</th>
                                    <th>GL1_停止燈</th>
                                    <th>RL1_運轉燈</th>
                                    <th>YL1_異常燈</th>
                                </tr>
                            </table>
                            <table>
                                <tr>
                                    <td><img id="myImage20" onclick="changeImage20()" src="image/button_remoteOFF.png"></td>
				   <td><img id="myImage21" onclick="changeImage21()" src="image/button_endOFF.png"></td>
				     <!--<td><img id="myImage22" onclick="changeImage22()" src="image/button_releaseOFF.png"></td>-->
                                   
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

          <!--  <div id="footer">footer</div> -->

        </div>
	<!--使用者界面顯示-->
<script>
if(<?php echo $login_check; ?> == 0){
	document.getElementById("login_inf").style.display = "none";
} else {
	document.getElementById("login_but").style.display = "none";
}
</script>
    </body>
</html>
