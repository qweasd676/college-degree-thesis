#!/usr/bin/env python
# -*- coding: utf-8 -*-
# install pyModbusTCP ref: https://pypi.org/project/pyModbusTCP/

from pyModbusTCP.client import ModbusClient
import time
import MySQLdb
#ge連結
HOST1 = "120.113.74.176"
PORT1 = 10000
c1 = ModbusClient()

# 定義modbus server IP 和 port
c1.host(HOST1)
c1.port(PORT1)
#set UID to 1
c1.unit_id(1)

while True:
	#開啟資料庫連接
	db = MySQLdb.connect(host="localhost",	
	user="project", passwd="n0u9dceo", db="project")
	#使用cursor()方法獲取操作游標
	cursor = db.cursor()
	#執行Mysql語法查詢資料
	cursor.execute("SELECT flow_rate FROM flow_rate_table order by time desc limit 1")

	#以陣列或以物件方式回傳
	result = cursor.fetchall()
	#寫入參數reg內
	for reg in result:
	  flow_rate = reg[0]

	#錯誤時返回
	db.commit()
	#關閉資料庫連接
	db.close()

	# 開啟或重新連接GE
	if not c1.is_open():
		if not c1.open():
			print("unable to connect to "+HOST1+":"+str(PORT1))

    	# 若開啟成功，讀取記憶體
	if c1.is_open():
        	# 讀取%R記憶體
		c1.write_single_register(31, flow_rate)
		if (flow_rate):
	    	   #顯示記憶體內容
		   print(flow_rate)

    # 停2秒後開始下個迴圈
	time.sleep(2)
