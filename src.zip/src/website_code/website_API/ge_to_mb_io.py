#!/usr/bin/env python
# -*- coding: utf-8 -*-
# install pyModbusTCP ref: https://pypi.org/project/pyModbusTCP/

from pyModbusTCP.client import ModbusClient
import time
import MySQLdb
#ge連結
HOST1 = "120.113.74.176"
PORT1 = 10000
c1 = ModbusClient()

# 定義modbus server IP 和 port
c1.host(HOST1)
c1.port(PORT1)
#set UID to 1
c1.unit_id(1)

while True:
    # 開啟或重新連接GE
    if not c1.is_open():
        if not c1.open():
            print("unable to connect to "+HOST1+":"+str(PORT1))

    # 若開啟成功，讀取記憶體
    if c1.is_open():
        # 讀取%R記憶體
        Manual = c1.read_holding_registers(51,1)
        Auto = c1.read_holding_registers(52,1)
        Abnormal = c1.read_holding_registers(53,1)
        COS_A = c1.read_holding_registers(40,1)
        COS_B = c1.read_holding_registers(41,1)
        EMS_A = c1.read_holding_registers(42,1)
        PB1 = c1.read_holding_registers(43,1)
        PB2 = c1.read_holding_registers(44,1)
        PB3 = c1.read_holding_registers(45,1)
        Relay_Motor = c1.read_holding_registers(46,1)
        GL1 = c1.read_holding_registers(47,1)
        RL1 = c1.read_holding_registers(48,1)
        YL1 = c1.read_holding_registers(49,1)
        
        if (Manual[0] or Auto[0] or Abnormal[0] or COS_A[0] or COS_B[0] or EMS_A[0] or PB1[0] or PB2[0] or PB3[0] or Relay_Motor[0] or GL1[0] or RL1[0] or YL1[0]):
	    #顯示記憶體內容
            print(Manual[0], Auto[0], Abnormal[0],COS_A[0], COS_B[0], EMS_A[0], PB1[0], PB2[0], PB3[0], Relay_Motor[0], GL1[0], RL1[0], YL1[0])
	    #開啟資料庫連接
	    db = MySQLdb.connect(host="localhost",	
	    user="project", passwd="n0u9dceo", db="project")
	    #使用cursor()方法獲取操作游標
	    cursor = db.cursor()
	    #執行Mysql語法插入資料
	    cursor.execute('UPDATE IO_Status SET Manual=%s,Auto=%s,Abnormal=%s,COS_A=%s,COS_B=%s,EMS_A=%s,PB1=%s,PB2=%s,PB3=%s,Relay_Motor=%s,GL1=%s,RL1=%s,YL1=%s WHERE 1',[Manual[0], Auto[0], Abnormal[0],COS_A[0], COS_B[0], EMS_A[0], PB1[0], PB2[0], PB3[0], Relay_Motor[0], GL1[0], RL1[0], YL1[0]]
			  )

	    #錯誤時返回
	    db.commit()
	    #關閉資料庫連接
	    db.close()

        
    # 停1秒後開始下個迴圈
    time.sleep(1)

