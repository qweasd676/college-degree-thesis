<?php 
session_start(); 
?>
<?php 
include("home_page/php/mysql_connect.inc.php");

if($_SESSION['username'] == null){
	$login_check = 0;
}else{
	$login_check = 1;
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>home page</title>
	<!--導入CSS--->
<link href="home_page/css/phone_style.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 1022px)" />
<link href="home_page/css/desktop_style.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 1023px)" />

	<!--ajax & bootstrap 導入函式--->
<link rel="stylesheet" href="home_page/css/bootstrap.min.css">
<script src="home_page/scripts/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


	<!--視差滾動 導入函式--->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
<script type="text/javascript" src="home_page/scripts/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="home_page/scripts/jquery.localscroll-1.2.7-min.js"></script>
<script type="text/javascript" src="home_page/scripts/jquery.scrollTo-1.4.2-min.js"></script>
<script src="home_page/scripts/parallax.js"></script>

	<!--dailog 導入函式--->
<link href="http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet"> 
<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<script src="home_page/scripts/dialog.js"></script>
<script src="home_page/scripts/login-registration.js"></script>

</head>

	<body>
	<!--選單列--->
		<nav class="navbar bg-dark navbar-dark navbar-expand-sm justify-content-between fixed-top">
	<!--navbar logo-->
			<a class="navbar-brand" href="#"><img src="http://120.113.74.177/home_page/images/water5.png" alt="logo" style= "height:55px;"></a>
	<!--下拉選單-->
			<button id="collapse_btn" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
				<ul id="nav" class="navbar-nav">
					<li class="nav-item"><a id="test1" class="nav-link" href="#intro">首頁</a></li>
					<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">關於</a>
						<div class="dropdown-menu">
							<a class="dropdown-item" href="#second">摘要</a>
							<a class="dropdown-item" href="#third">研究動機</a>
							<a class="dropdown-item" href="#forth" >實作影片</a>
						</div>
					</li>
					<div id="login_but">
						<li class="nav-item dropdown"><a class="nav-link" href="#" id="login_btn">使用者登入</a></li>
					</div>
					<div id="login_inf">
						<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">工作人員專區</a>
							<div class="dropdown-menu">
									<a class="dropdown-item" href="#" ><?php echo "user:".$_SESSION['username']?></a>
									<a class="dropdown-item" href="home_page/php/logout.php">使用者登出</a>
									<a class="dropdown-item" href="monitor_platform/index.php">數據監測</a>	
							</div>
						</li>
					</div>
				</ul>
			</div>
		</nav>
			

	<!--登入介面--->
		<div id="login_dialog" title="登入" class="loginbox">
			<img src="home_page/images/login.png" class="login">
			<h1>登入系統</h1>
			<div class="error-message" id="login-error-message" style="display: none"></div>
			<form id="login_form" name="login_form" action="" method="post">
				<span id="account_info"></span><br>
				<p>帳號：<input type="text" name="login_account_id" id="login_account_id" class="input_field" placeholder="account"></p>
				<span id="password_info"></span><br> 
				<p>密碼：<input type="password" name="login_password" id="login_password" class="input_field" placeholder="Password"/> <br></p>
				<input id="login_b" type="button" value="登入" onclick="ajaxLogin()">
			</form>
			<button id="create">申請帳號</button><br>
		</div>
			
	<!--申請介面--->
		<div id="register-dialog" title="申請" class="registerbox">
			<form name="register-form" id="register-form" method="post">
				<span id="user-name-info"></span>
				<p>姓名：<input type="text" name="user-name" id="user-name" /> <br></p>
				<span id="account-info"></span>
				<p>帳號：<input type="text" name="account"  id="account" /> <br></p>
				<span id="register-email-info"></span>
				<p>e-mail：<input type="email" name="register-email-id"  id="register-email-id" /> <br></p>
				<span id="contact-no-info"></span>
				<p>連絡電話：<input type="text" name="contact-number"  id="contact-number" maxlength="10" /> <br></p>
				<span id="register-passwd-info"></span>
				<p>密碼：<input type="password" name="register-password" id="register-password" /> <br></p>
				<span id="confirm-passwd-info"></span>
				<p>再一次輸入密碼：<input type="password" name="confirm-password" id="confirm-password" /> <br></p>
				<input type="button" onclick="ajaxRegistration()" value="確定">
			</form>	
		</div>	
			
			

	<!--首頁--->
		<div id="intro">
			<div class="story">
				<div class="center">
					<div class="desktop">
						<h2>應用於淨水廠水質監控物聯網系統</h2>
					</div>
					<div class="phone">
						<h2>應用於淨水廠水質</h2>
						<h2>監控物聯網系統</h2>
					</div>
				</div>
			</div> <!--.story-->
		</div> <!--#intro-->
			
	<!--摘要--->
		<div id="second">
			<div class="story">
				<div class="float-right">
					<h2>摘要</h2>
					<p>科技日新月異，科技產業蓬勃發展以及地球氣候變遷，許多珍貴的自然資源愈來愈稀少，其中水是我們人類維持生命不可或缺的其中一種資源，但是在生活當中有很多因素讓這些重要的水資源流失或是被汙染，但目前監控系統有種種問題，並且國人對於水資源如何被處理並非很了解。</p>
					<p>所以本計畫以建立一個監控及控制水資源的軟硬體系統為目標，結合資料庫、<p1>PAC (Programmable Automation Controllers，可程式自動化控制器)</p1><p2>PAC (Programm-able Automation Controllers，可程式自動化控制器)</p2> 以及各種感應器，使得操作人員能夠在第一時間更精確的判斷各數值的正確性，以最短時間作出最佳的處理方法提升工作效率，並減少人員工作量，降低人員操作失誤所造成的損失，並使得管理人員更加方便管理，大大提升管理層與操作人員之間對於彼此的信心，利用該系統來達成管理方便及操作輕鬆的雙贏的局面。</p>
				</div>
			</div> <!--.story-->
		</div> <!--#second-->


	<!--研究動機--->
		<div id="third">
			<div class="story">
				<div class="float-right">
					<h2>研究動機與研究問題</h2>
					<p>可利用的水資源日益稀少所以對於水資源的監控與控制的議題越來越重要，過去能利用各種感測器監測水的流量、流速及水質等等數據，並將數據進行分析後顯示給操作人員，進行場區的控制，但目前多數系統對於大數據分析處理得資料量到一定數量時易造成當機的問題，使得操作人員無法對水系統進行判斷及處理，造成極大的損失，我們將資料上傳至資料庫進行資料的分析，達到最佳的精確度，讓系統本身自動控制場區內各個機具，協助操作人員更加準確的判斷及讓管理人員更加了解各操作人員工作狀況。</p>
					<p>目標為研究如何利用<p1>GE_PAC</p1><p2>GE_PAC</p2>加上各種感測器與<p1>Linux Ubuntu</p1><p2>Linux Ubuntu</p2>作業系統內的免費軟體，架構一平台，降低其他系統所需的授權費，在利用<p1>PHP</p1><p2>PHP</p2>架構一網頁，讓人能夠對於各數據更一目瞭然，同時利用<p1>MySQL</p1><p2>MySQL</p2>建立資料庫，傳送所監控到的各數據至資料庫進行分析，若數值發生異常立刻對操作人員發出警告提醒，並立刻控制各機具使異常被排除，而這些數據將同步顯示於網頁讓各工作人員更及時了解，對於所用的水能夠使人更加安心。</p>
				</div>
			</div> <!--.story-->
		</div> <!--#third-->
			

	<!--觀看影片-->
		<div id="forth">
			<div class="story">
				<div class="float-left">
					<div class="center">
						<h2>實做影片</h2>
						<video width="95%" height="100%" controls>
						  <source src="home_page/video/test.mp4" type="video/mp4">
						</video>
					</div>
				</div>
			</div> <!--.story-->
		</div> <!--#forth-->
			
		<div id="footer">
			<div class="story">
				<div class="center">
				<p>國立虎尾科技大學 National Formosa University © All RIGHTS RESERVED.</p>
				</div>				
				<p>校務資訊聯絡單位：秘書室 E-Mail：secretary@nfu.edu.tw電話：886-5-6315000 傳真：886-5-6315999 統一編號：64967512地址：632 雲林縣虎尾鎮文化路64號 No.64</p>
				<p>版權聯絡單位：電算中心網路組 E-Mail：network@nfu.edu.tw，若您對本站資料之版權有疑慮，請與網路組聯絡。</p>	        
				
<!--
				<h2>Ian Lunn</h2>
				<ul>
					<li><strong>Twitter</strong>: <a href="http://www.twitter.com/IanLunn" title="Follow Ian on Twitter">@IanLunn</a></li>
					<li><strong>GitHub</strong>: <a href="http://www.github.com/IanLunn" title="Follow Ian on GitHub">IanLunn</a></li>
					<li><strong>Website</strong>: <a href="http://www.ianlunn.co.uk/" title="Ian Lunn Design">www.ianlunn.co.uk</a></li>
				</ul>
				<p>This demo is based on the <a href="http://www.nikebetterworld.com" title="Nike Better World">Nikebetterworld.com</a> website.</p>	        
				<h2>Credits</h2>
				<p>This plugin makes use of some scripts and images made by others:</p>
				<ul>
					<li><a href="http://flesler.blogspot.com/2007/10/jqueryscrollto.html" title="jQuery ScrollTo">jQuery ScrollTo</a></li>
					<li><a href="http://downloads.dvq.co.nz/" title="Background Textures">Wooden and Pyschedlic Background Textures</a></li>
					<li><a href="http://www.sxc.hu/photo/931435" title="Trainers Image">Trainers Image</a></li>
					<li><a href="http://www.sxc.hu/photo/1015485" title="Basketball Image">Basketball Image</a></li>
					<li><a href="http://www.sxc.hu/photo/563767" title="Bottles Image">Bottles Image</a></li>
				</ul>-->
			</div> <!--.story-->
		</div> <!--#fifth-->
			<!--使用者界面顯示-->
		<script>
			if(<?php echo $login_check; ?> == 0){
				document.getElementById("login_inf").style.display = "none";
			} else {
				document.getElementById("login_but").style.display = "none";
			}
		</script>
		
		<!--折疊下拉式選單-->
		<script>
			$(function(){
				$('#test1, .navbar .dropdown-item, #login_but .dropdown').click(function(){
					$('.navbar-toggler').click();
				});
			});
		</script>
	</body>
</html>
