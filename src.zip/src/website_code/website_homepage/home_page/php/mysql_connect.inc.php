<?php
$conn=new mysqli('localhost','project','n0u9dceo','project');	//固定ip,帳號,密碼,資料庫名稱

?>  
