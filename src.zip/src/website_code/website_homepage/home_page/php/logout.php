<?php
session_start();
unset($_SESSION['account']);
unset($_SESSION['username']);
unset($_SESSION['password']);
unset($_SESSION['viewer_qualification']);
session_destroy();
header("Location: http://120.113.74.177/index.php");
?>
