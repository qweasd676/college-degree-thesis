<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once ('mysql_connect.inc.php');

function validateData($data)
{
    $resultData = htmlspecialchars(stripslashes(trim($data)));
    return $resultData;
}

if (isset($_POST['action']) && $_POST['action'] == 'registration') {
    $username = validateData($_POST['userName']);
    $account = validateData($_POST['account']);
    $email_id = validateData($_POST['emailId']);
    $contact_number = validateData($_POST['contactNumber']);
    $password = validateData($_POST['password']);
    $confirm_password = validateData($_POST['confirmPassword']);
    
    $error_message = '';
    $checkEmailQuery = $conn->prepare("select * from member_table where email_id = ?");
    $checkEmailQuery->bind_param("s", $email_id);
    $checkEmailQuery->execute();
    
    $result = $checkEmailQuery->get_result();
    if ($result->num_rows > 0) {
        
        $error_message = "Email ID already exists !";
        echo $error_message;
    } else {
        $insertQuery = $conn->prepare("insert into member_table(username,account,email_id,contact_number,password) values(?,?,?,?,?)");

        $insertQuery->bind_param("sssss", $username, $account, $email_id, $contact_number, $password);
        
        if ($insertQuery->execute()) {
            echo "Thankyou for registering with us. You can login now.";
            exit();
        } else {
            $error_message = "error";
        }
        $insertQuery->close();
        $conn->close();
        
        echo $error_message;
    }
}

if (isset($_POST['action']) && $_POST['action'] == 'login') {
    $account = validateData($_POST['account']);
    $password = validateData($_POST['password']);

    $error_message = '';
    
    $selectQuery = $conn->prepare("select * from member_table where account = ? and password = ?");
    $selectQuery->bind_param("ss", $account, $password);
    $selectQuery->execute();
    
    $result = $selectQuery->get_result();
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION['username'] = $row['username'];
	    $_SESSION['viewer_qualification'] = $row['viewer_qualification'];
            exit();
        } // endwhile
    } // endif
else {
        $error_message = "error";
    } // endElse
    $conn->close();
    
    echo $error_message;
}
?>
