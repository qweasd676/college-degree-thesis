	$(function() {
		//設定對話窗規格
		$( "#login_dialog" ).dialog({
			autoOpen: false,
			modal: true,
			height: 650,
			width: 400,
			position: 'center',
			position: 'center',
			
		});
		
		$( "#register-dialog" ).dialog({
			autoOpen: false,
			modal: true,
			height: 320,
			width: 550,
		});
		//呼叫登入跟註冊對話窗
		$( "#login_btn" ).click(function() {
			$( "#login_dialog" ).dialog( "open" );
		});	
		$( "#create" ).click(function() {
			$( "#register-dialog" ).dialog( "open" );
			$( "#login_dialog" ).dialog( "close" );
		});
		//可用enter key 登入
		$("#login_account_id").keyup(function(event) {
		    if (event.keyCode === 13) {
			$("#login_b").click();
		    }
		});
		$("#login_password").keyup(function(event) {
		    if (event.keyCode === 13) {
			$("#login_b").click();
		    }
		});

		
		
	});
