function validateEmailId(input) {
	var emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

	if (emailFormat.test(input)) {
		return true;
	} else {
		return false;
	}
}

function pregMatch(input) {
	var regExp = /^[a-zA-Z ]*$/;

	if (regExp.test(input)) {
		return true;
	} else {
		return false
	}
}

function acctpwdMatch(input) {
	var accctpwdFormat = /^[a-zA-Z0-9 ]*$/;

	if (accctpwdFormat.test(input)) {
		return true;
	} else {
		return false
	}
}


function ajaxRegistration() {
	$(".error").text("");
	$('#user-name-info').removeClass("error");
	$('#account-info').removeClass("error");
	$('#register-email-info').removeClass("error");
	$('#contact-no-info').removeClass("error");
	$('#register-passwd-info').removeClass("error");
	$('#confirm-passwd-info').removeClass("error");

	var userName = $('#user-name').val();
	var account = $('#account').val();
	var emailId = $('#register-email-id').val();
	var contactNumber = $('#contact-number').val();
	var password = $('#register-password').val();
	var confirmPassword = $('#confirm-password').val();
	var actionString = 'registration';

	if (userName == "") {
		$('#user-name-info').addClass("error");
		$(".error").text("請輸入使用者名稱");
	} else if (!pregMatch(userName)) {
		$('#user-name-info').addClass("error");
		$(".error").text('Alphabets and white space allowed');
	} else if (account == "") {
		$('#account-info').addClass("error");
		$(".error").text("請輸入帳號");
	} else if (!acctpwdMatch(account)) {
		$('#account-info').addClass("error");
		$(".error").text('Alphabets and white space allowed');
	} else if (emailId == "") {
		$('#register-email-info').addClass("error");
		$(".error").text("請輸入e-mail");
	} else if (!validateEmailId(emailId)) {
		$('#register-email-info').addClass("error");
		$(".error").text("Invalid");
	} else if (contactNumber == "") {
		$('#contact-no-info').addClass("error");
		$(".error").text("請輸入聯絡電話");
	} else if (isNaN(contactNumber) || (contactNumber.indexOf(" ") != -1) || contactNumber.length > 10) {
		$('#contact-no-info').addClass("error");
		$(".error").text("Invalid");
	} else if (password == "") {
		$('#register-passwd-info').addClass("error");
		$(".error").text("請輸入密碼");
	} else if (confirmPassword == "") {
		$('#confirm-passwd-info').addClass("error");
		$(".error").text("與輸入密碼不合");
	} else if (password != confirmPassword) {
		$('#confirm-passwd-info').addClass("error");
		$(".error").text("與輸入密碼不合");
	} else {
		$('#loaderId').show();
		$.ajax({
			url : "home_page/php/ajax-login-registration.php",
			type : 'POST',
			data : {
				userName : userName,
				account : account,
				emailId : emailId,
				contactNumber : contactNumber,
				password : password,
				confirmPassword : confirmPassword,
				action : actionString
			},
			success : function(response) {
				if (response.trim() == 'error') {
					$('#register-success-message').hide();
					$('#ajaxloader').hide();
					$('#register-error-message').html(
							"Invalid Attempt. Try Again.");
					$('#register-error-message').show();
				} else {
					$(".thank-you-registration").show();
					$(".thank-you-registration").text(response);
					$("#register-dialog").dialog("close");
					$("#login-dialog").dialog("open");						
				}
				
			}

		});
		this.close();
	}// endif
}

// Function for user login
function ajaxLogin() {
	$(".error").text("");
	$('#account_info').removeClass("error");
	$('#password_info').removeClass("error");

	var account = $('#login_account_id').val();
	var password = $('#login_password').val();
	var actionString = 'login';

	if (account == "") {
		$('#account_info').addClass("error");
		$(".error").text("帳號不可為空");
	} else if (password == "") {
		$('#password_info').addClass("error");
		$(".error").text("密碼不可為空");
	} else {
		// show loader
		$('#loaderId').show();
		$.ajax({
			url : "home_page/php/ajax-login-registration.php",
			type : "POST",
			data : {
				account : account,
				password : password,
				action : actionString
			},
			success : function(response) {
				if (response.trim() == 'error') {
					$('#login-success-message').hide();
					$('#ajaxloader').hide();
					$('#login-error-message').html(
							"輸入帳號或密碼有誤 請重新輸入");
					$('#login-error-message').show();
				} else {
					$('.demo-container').html(response);
					//register_window.dialog("close");
					$("#login_dialog").dialog("close");
					setTimeout(window.location.reload(true),3000);
				}
				
			}
		});
		this.close();
	}// endif
}
